from django.contrib import admin
from homePage.models import Aficion 
from homePage.models import infousuario
# Register your models here.
admin.site.register(Aficion)
admin.site.register(infousuario)